 <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />

<div style="width:1048px; height:300px; border:solid 1px #D2D2FF;">

<div id="slider" style="width:1048px; height:300px;border:solid 0px #FFF;" align="center";>
<img src="images/wrkr.jpg"  height="345" width="1047"/>
<img src="images/jobb.jpg"  />
<img src="images/job3.jpg"  />
	   </div>

       </div>
