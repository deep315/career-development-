<div style="width:1050px; height:40px; background-color:#4171AF; border-radius:0px; border:0px solid #000000; margin:auto;">

<link rel="stylesheet" href="css_menu3/style.css" type="text/css" /><style type="text/css">._css3m{display:none}</style>
<div style="float:left; width:1050px;height:40px; " >
<ul id="css3menu12" class="topmenu">
	  <li class="topmenu"><a href="index.php" style="height:40px;line-height:40px; width:40px;"><div style="padding-left:0px;"><center><img src="images/home-btn.jpg"         </center></div></a></li>

	  <li class="toplast"><a href="#" style="height:40px;line-height:40px;width:160px;"><div style="padding-left:10px;"><center><b>Resume Forward</b></center></div></a>
         <ul>
	        <li><a href="ResumeForwardIndia.php"><b>Resume Forward ELE</b></a></li>
            <li><a href="ResumeForwardInternational.php"><b>Resume Forward International</b></a></li>
            <li><a href="ResumeForwardBoth.php"><b>Resume Forward Both</b></a></li>
    	 </ul>
	   </li>

	  <li class="toplast"><a href="#" style="height:40px;line-height:40px;width:145px;"><div style="padding-left:10px;"><center><b>Resume Writing</b></center></div></a>
         <ul>
	        <li ><a href="ResumeWritingIndia.php"><b>Resume Writing ELE</b></a></li>
            <li><a href="ResumeWritingInternational.php"><b>Resume Writing International</b></a></li>
            <li><a href="ResumeWritingBoth.php"><b>Resume Writing Both</b></a></li>
            <li><a href="CoverLetterIndia.php"><b>Cover Letter ELE</b></a></li>
            <li><a href="CoverLetterInternational.php"><b>Cover Letter International</b></a></li>
		 </ul>
	  </li>


	 <li class="toplast"><a href="JobSeeker.php" style="height:40px;line-height:40px; width:143px;"><div style="padding-left:10px;"><center><b>Job Seeker</b></center>
	         </div></a>
         <ul>
	        <li><a href="InterviewPreparation.php"><b>Interview Prepration</b></a></li>
		</ul>
	 </li>


	 <li class="topmenu"><a href="#" style="height:40px;line-height:40px; width:130px;"><div style="padding-left:0px;"><center><b> Career Report</b></center></div></a>
	    <ul>
	        <li><a href="Career&FinanceReport.php"><b>Career & Finance Report</b></a></li>
            <li><a href="JobChangePlanning.php"><b>Job Change Planning</b></a></li>
		</ul>
	 </li>


	 <li class="topmenu"><a href="#" style="height:40px;line-height:40px; width:175px;"><div style="padding-left:15px;"><center><b>Profile Verification</b></center>              </div></a>
	     <ul>
	        <li><a href="EducationVerification.php"><b>Education Verification</b></a></li>
            <li><a href="EmployeeVerification.php"><b>Employment Verification</b></a></li>
            <li><a href="Employee&EducationVerification.php"><b>Both Verification</b></a></li>
		 </ul>
	  </li>


	<li class="topmenu"><a href="GrowthCombo.php" style="height:40px;line-height:40px;width:139px;"><div style="padding-left:5px;"><center><b>Growth Combo</b></center>             </div></a></li>

	<li class="toplast"><a href="login.php" style="height:40px;line-height:40px;border:solid 0px #00FF00; width:99px;"><div style="padding-left:10px;"><center><b>Login            </b></center></div></a>  </li>
</ul>
</div>
</div>
